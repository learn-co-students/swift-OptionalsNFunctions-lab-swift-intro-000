//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func produceFullName(withFirstName firstName: String, middleName: String?, lastName: String) -> String {
    
    var name = firstName
    
    if let middleName = middleName {
        name = "\(name) \(middleName)"
    }
    
    name = "\(name) \(lastName)"
    
    return name
}

produceFullName(withFirstName: "Jon", middleName: "Bon", lastName: "Jovi")

produceFullName(withFirstName: "Mary", middleName: nil, lastName: "Doe")

